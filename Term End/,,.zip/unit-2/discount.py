amount=1000

if amount >=1000:
    amount-=amount*0.1
elif amount >=500:
    amount-=amount*0.2
elif amount>=300:
    amount-=amount*0.05

print (amount)
