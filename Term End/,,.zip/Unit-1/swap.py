num1=5
num2=10
num1=num1+num2
num2=num1-num2
num1=num1-num2
print(num1,num2)