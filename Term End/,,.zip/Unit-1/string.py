str="Hello"
print(len(str))
rev_str=str[::-1]
print(rev_str)

