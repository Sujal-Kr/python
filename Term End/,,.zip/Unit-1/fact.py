num=6
ans=1
while num > 0:
    ans*=num
    num -= 1

print(ans)
