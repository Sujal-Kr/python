str="hey"
ptr="hello"
merged=str+ptr
print(merged)


